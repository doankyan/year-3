import org.scalatest.FunSuite
import mc.utils._

/**
  * Created by nhphung on 4/29/17.
  */
class AstSuite extends FunSuite with TestAst {
test("multi declearations") {
    val input =
      """int foo(){}
        |string a;
        |float[] bar(){}
        |boolean y,j[3];
        |int a,b,c;
        |float func(){}
      """.stripMargin
    val expected = Program(List(FuncDecl(Id("foo"),List(),IntType,Block(List(),List())),VarDecl(Id("a"),StringType),FuncDecl(Id("bar"),List(),ArrayPointerType(FloatType),Block(List(),List())),VarDecl(Id("y"),BoolType),VarDecl(Id("j"),ArrayType(IntLiteral(3),BoolType)),VarDecl(Id("a"),IntType),VarDecl(Id("b"),IntType),VarDecl(Id("c"),IntType),FuncDecl(Id("func"),List(),FloatType,Block(List(),List()))))
    assert(checkAst(input, expected, 201))
  }
  test("if statement fully within another if statement fully in then part ") {
    val input =
      """int func(){if (a) if (b) c; else d; else e;}"""
    val expected = Program(List(FuncDecl(Id("func"),List(),IntType,Block(List(),List(If(Id("a"),If(Id("b"),Id("c"),Some(Id("d"))),Some(Id("e"))))))))
    assert(checkAst(input,expected,202))
  }
  test("every statement") {
    val input =
      """int func(){
        |if (k=1) do {m=n||t; if (m==true) { k=k+1; continue;}} while k>3;
        |else for ("";"";"") {return ""; break;}}""".stripMargin
    val expected = Program(List(FuncDecl(Id("func"),List(),
      IntType,Block(List(),List(If(BinaryOp("=",Id("k"),IntLiteral(1)),
      Dowhile(List(Block(List(),List(BinaryOp("=",Id("m"),BinaryOp("||",Id("n"),Id("t"))),
      If(BinaryOp("==",Id("m"),BooleanLiteral(true)),Block(List(),List(BinaryOp("=",Id("k"),BinaryOp("+",Id("k"),IntLiteral(1))),
      Continue)),None)))),BinaryOp(">",Id("k"),IntLiteral(3))),Some(For(StringLiteral(""),StringLiteral(""),StringLiteral(""),
      Block(List(),List(Return(Some(StringLiteral(""))),Break))))))))))
    assert(checkAst(input, expected, 203))
  }
  test("array") {
    val input = """ int a[3];"""
    val expected = Program(List(VarDecl(Id("a"),ArrayType(IntLiteral(3),IntType))))
    assert(checkAst(input,expected,204))
  }

  test("array 2: wrong") {
    val input = """ void main() { 3[a+5] = 2;}"""
    val expected =Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),List(BinaryOp("=",ArrayCell(IntLiteral(3),BinaryOp("+",Id("a"),IntLiteral(5))),IntLiteral(2)))))))
    assert(checkAst(input,expected,205))
}
  test("VarDecl 1"){
    val input  = """int a;"""
    val expected = Program(List(VarDecl(Id("a"),IntType)))
    assert(checkAst(input,expected,206))
  }
  test("VarDecl 2"){
    val input = """float arr[5];"""
    val expected = Program(List(VarDecl(Id("arr"),ArrayType(IntLiteral(5),FloatType))))
    assert(checkAst(input,expected,207))
  }
  test("list vardecl 1"){
    val input = """boolean a,b,c;"""
    val expected = Program(List(VarDecl(Id("a"),BoolType),VarDecl(Id("b"),BoolType),VarDecl(Id("c"),BoolType)))
    assert(checkAst(input,expected,208))
  }
  test("list vadecl 2"){
    val input= """
    int a,array[10];
    boolean bool, k[5];
    string str1,str2;
    """
    val expected = Program(List(VarDecl(Id("a"),IntType),VarDecl(Id("array"),ArrayType(IntLiteral(10),IntType)),
      VarDecl(Id("bool"),BoolType),VarDecl(Id("k"),ArrayType(IntLiteral(5),BoolType)),VarDecl(Id("str1"),StringType),
      VarDecl(Id("str2"),StringType)))
    assert(checkAst(input,expected,209))
  }
  test("funcdecl 1: null paralist and stmt"){
    val input = """
    void main() {}
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),List()))))
    assert(checkAst(input,expected,210))
  }
  test("funcdecl 2.1: has paralist "){
    val input = """
    void main(float a){}
    """
    val expected = Program(List(FuncDecl(Id("main"),List(VarDecl(Id("a"),FloatType)),VoidType,Block(List(),List()))))
    assert(checkAst(input,expected,211))
  }
  test("funcdecl 2.2: has paralist"){
    val input = """
    void main(int a, float b, boolean bool[]){}
    """
    val expected = Program(List(FuncDecl(Id("main"),List(VarDecl(Id("a"),IntType),VarDecl(Id("b"),FloatType),
      VarDecl(Id("bool"),ArrayPointerType(BoolType))),VoidType,Block(List(),List()))))
    assert(checkAst(input,expected,212))
  }
  test("funcdecl 3.1: has stmt"){
    val input = """
    void main(int a){ a = 2;}
    """
    val expected = Program(List(FuncDecl(Id("main"),List(VarDecl(Id("a"),IntType)),
      VoidType,Block(List(),List(BinaryOp("=",Id("a"),IntLiteral(2)))))))
    assert(checkAst(input,expected,213))
  }
  test("funcdecl 3.2: has stmt"){
    val input = """
    float main(){ a = 2;}
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),FloatType,Block(List(),
      List(BinaryOp("=",Id("a"),IntLiteral(2)))))))
    assert(checkAst(input,expected,214))
  }
  test("funcdecl 4.1: type funcdecl"){
    val input = """
    string[] main(int a){ a = 2;}
    """
    val expected = Program(List(FuncDecl(Id("main"),List(VarDecl(Id("a"),IntType)),
      ArrayPointerType(StringType),Block(List(),List(BinaryOp("=",Id("a"),IntLiteral(2)))))))
    assert(checkAst(input,expected,215))
  }
  test("vardecl and funcdecl 1: "){
    val input = """
    int a;
    void main(){}
    """
    val expected = Program(List(VarDecl(Id("a"),IntType),FuncDecl(Id("main"),List(),VoidType,Block(List(),List()))))
    assert(checkAst(input,expected,216))
  }
   test("vardecl and funcdecl 2: "){
    val input = """
    int a,b[5];
    void main(){}
    string str[6];
    """
    val expected = Program(List(VarDecl(Id("a"),IntType),VarDecl(Id("b"),ArrayType(IntLiteral(5),IntType)),
      FuncDecl(Id("main"),List(),VoidType,Block(List(),List())),VarDecl(Id("str"),ArrayType(IntLiteral(6),StringType))))
    assert(checkAst(input,expected,217))
  }
   test("vardecl and funcdecl 3: "){
    val input = """
    int a,b,c;
    void main(int a, int b, int c){  a = 2;}
    """
    val expected = Program(List(VarDecl(Id("a"),IntType),VarDecl(Id("b"),IntType),
      VarDecl(Id("c"),IntType),FuncDecl(Id("main"),List(VarDecl(Id("a"),IntType),
      VarDecl(Id("b"),IntType),
      VarDecl(Id("c"),IntType)),VoidType,Block(List(),List(BinaryOp("=",Id("a"),IntLiteral(2)))))))
    assert(checkAst(input,expected,218))
  }
     test("vardecl and funcdecl 4: "){
    val input = """
    int a;
    void main(float b){ b = 2;}
    int func() { int i;}
    """
    val expected =Program(List(VarDecl(Id("a"),IntType),
      FuncDecl(Id("main"),List(VarDecl(Id("b"),FloatType)),VoidType,Block(List(),List(BinaryOp("=",Id("b"),IntLiteral(2))))),
      FuncDecl(Id("func"),List(),IntType,Block(List(VarDecl(Id("i"),IntType)),List()))))
    assert(checkAst(input,expected,219))
  }
  test("vardecl and funcdecl 5: "){
    val input = """
    int a,mang[5];
    void f(int arr[]){arr[1] = a;}
    float d[5];
    int main(){ boolean b;}
    """
    val expected = Program(List(VarDecl(Id("a"),IntType),VarDecl(Id("mang"),ArrayType(IntLiteral(5),IntType)),
      FuncDecl(Id("f"),List(VarDecl(Id("arr"),ArrayPointerType(IntType))),VoidType,Block(List(),List(BinaryOp("=",ArrayCell(Id("arr"),IntLiteral(1)),Id("a"))))),
      VarDecl(Id("d"),ArrayType(IntLiteral(5),FloatType)),
      FuncDecl(Id("main"),List(),IntType,Block(List(VarDecl(Id("b"),BoolType)),List()))))
    assert(checkAst(input,expected,220))
  }
  test("stmt 1.1: ifstmt"){
    val input = """
    void main() {
      int a,b[5];
      if(a>2) b[1];
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(VarDecl(Id("a"),IntType),
      VarDecl(Id("b"),ArrayType(IntLiteral(5),IntType))),List(If(BinaryOp(">",Id("a"),IntLiteral(2)),ArrayCell(Id("b"),
        IntLiteral(1)),None))))))
    assert(checkAst(input,expected,221))
  }
  test("stmt 1.2: ifstmt"){
    val input = """
    void main() {
      int a,b[5];
      if(a>2) b[1]; else b[2];
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(VarDecl(Id("a"),IntType),
      VarDecl(Id("b"),ArrayType(IntLiteral(5),IntType))),List(If(BinaryOp(">",Id("a"),IntLiteral(2)),ArrayCell(Id("b"),
        IntLiteral(1)),Some(ArrayCell(Id("b"),IntLiteral(2)))))))))
    assert(checkAst(input,expected,222))
  }
  test("stmt 1.3: nest ifstmt"){
    val input = """
    void main() {
      int a,b[5];
      if(a>2) 
        if(a<5)b[1];
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,
      Block(List(VarDecl(Id("a"),IntType),VarDecl(Id("b"),ArrayType(IntLiteral(5),IntType))),
        List(If(BinaryOp(">",Id("a"),IntLiteral(2)),If(BinaryOp("<",Id("a"),IntLiteral(5)),ArrayCell(Id("b"),
          IntLiteral(1)),None),None))))))
    assert(checkAst(input,expected,223))
  }
  test("stmt 1.4: nest ifstmt"){
    val input = """
    void main() {
      int a,b[5];
      if(a>2) b[1]; else
        if(a>1) b[4];
          else b[2];
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(VarDecl(Id("a"),
      IntType),VarDecl(Id("b"),ArrayType(IntLiteral(5),IntType))),List(If(BinaryOp(">",Id("a"),IntLiteral(2)),
      ArrayCell(Id("b"),IntLiteral(1)),Some(If(BinaryOp(">",Id("a"),IntLiteral(1)),ArrayCell(Id("b"),IntLiteral(4)),
        Some(ArrayCell(Id("b"),IntLiteral(2)))))))))))
    assert(checkAst(input,expected,224))
  }
  test("stmt 1.5: ifstmt"){
    val input = """
    void main() {
      int a,b[5];
      if(a>1)
        if(a>2)
          if(a>3 && a < 50) 1; else 2;
        else 2;
      else 6;
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(VarDecl(Id("a"),
      IntType),VarDecl(Id("b"),ArrayType(IntLiteral(5),IntType))),List(If(BinaryOp(">",Id("a"),
        IntLiteral(1)),If(BinaryOp(">",Id("a"),IntLiteral(2)),If(BinaryOp("&&",BinaryOp(">",Id("a"),
          IntLiteral(3)),BinaryOp("<",Id("a"),IntLiteral(50))),IntLiteral(1),Some(IntLiteral(2))),
        Some(IntLiteral(2))),Some(IntLiteral(6))))))))
    assert(checkAst(input,expected,225))
  }
  test("stmt 2.1: call stmt"){
    val input = """
    void main(){
      foo(2);
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),
      VoidType,Block(List(),List(CallExpr(Id("foo"),List(IntLiteral(2))))))))
    assert(checkAst(input,expected,226))
  }
  test("stmt 2.2: call stmt"){
    val input = """
    void main(){
      foo(2,b[4],5);
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,
      Block(List(),List(CallExpr(Id("foo"),List(IntLiteral(2),ArrayCell(Id("b"),IntLiteral(4)),IntLiteral(5))))))))
    assert(checkAst(input,expected,227))
  }
  test("stmt 2.3: call stmt"){
    val input = """
    void main(){
      foo(func(2));
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),
      VoidType,Block(List(),List(CallExpr(Id("foo"),List(CallExpr(Id("func"),List(IntLiteral(2))))))))))
    assert(checkAst(input,expected,228))
  }
  test("stmt 2.4: call stmt"){
    val input = """
    void main(){
      foo(2)[7];
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(ArrayCell(CallExpr(Id("foo"),List(IntLiteral(2))),IntLiteral(7)))))))
    assert(checkAst(input,expected,229))
  }
  test("stmt 2.5: call stmt"){
    val input = """
    void main(){
      int a;
      a = 1;
      foo(2,3)[a+3];
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,
      Block(List(VarDecl(Id("a"),IntType)),List(BinaryOp("=",Id("a"),IntLiteral(1)),
      ArrayCell(CallExpr(Id("foo"),List(IntLiteral(2),IntLiteral(3))),BinaryOp("+",Id("a"),IntLiteral(3))))))))
    assert(checkAst(input,expected,230))
  }
  test("stmt 3.1: simple 1 dowhile stmt"){
    val input = """
    void main(){
      do 1;2;3; while a==1;
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(Dowhile(List(IntLiteral(1),IntLiteral(2),IntLiteral(3)),BinaryOp("==",Id("a"),IntLiteral(1))))))))
    assert(checkAst(input,expected,231))
  }
   test("stmt 3.1: simple 2 dowhile stmt"){
    val input = """
    void main(){
      do{}while a==1;
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(Dowhile(List(Block(List(),List())),BinaryOp("==",Id("a"),IntLiteral(1))))))))
    assert(checkAst(input,expected,232))
  }
   test("stmt 3.1: simple 3 dowhile stmt"){
    val input = """
    void main(){
      do{
        int a;
        a = a+2;
      }
      a + 4;
      while a==1;
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(Dowhile(List(Block(List(VarDecl(Id("a"),IntType)),List(BinaryOp("=",Id("a"),BinaryOp("+",Id("a"),
        IntLiteral(2))))),BinaryOp("+",Id("a"),IntLiteral(4))),BinaryOp("==",Id("a"),IntLiteral(1))))))))
    assert(checkAst(input,expected,233))
  }
   test("stmt 3.2: ifstmt and dowhile stmt"){
    val input = """
    void main(){
      do
        if(a>3) 5; else 6;
        { if(a<2) 7;}
        8;9;
      while (true);
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(Dowhile(List(If(BinaryOp(">",Id("a"),IntLiteral(3)),IntLiteral(5),Some(IntLiteral(6))),Block(List(),
        List(If(BinaryOp("<",Id("a"),IntLiteral(2)),IntLiteral(7),None))),IntLiteral(8),IntLiteral(9)),BooleanLiteral(true)))))))
    assert(checkAst(input,expected,234))
  }
   test("stmt 3.3: nest dowhile stmt 1"){
    val input = """
    void main(){
      do
        do 1;
        while(true);
      while a==1;
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(Dowhile(List(Dowhile(List(IntLiteral(1)),BooleanLiteral(true))),BinaryOp("==",Id("a"),IntLiteral(1))))))))
    assert(checkAst(input,expected,235))
  }
  test("stmt 3.3: nest dowhile stmt 2"){
    val input = """
    void main(){
      do
        do 1;
        while(true);
      while a==1;
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(Dowhile(List(Dowhile(List(IntLiteral(1)),BooleanLiteral(true))),BinaryOp("==",Id("a"),IntLiteral(1))))))))
    assert(checkAst(input,expected,236))
  }
  test("stmt 3.3: nest dowhile stmt 3"){
    val input = """
    void main(){
      do
        do 1;
          do {}
            while(false);
        while(true);
      while a==1;
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(Dowhile(List(Dowhile(List(IntLiteral(1),Dowhile(List(Block(List(),List())),BooleanLiteral(false))),
        BooleanLiteral(true))),BinaryOp("==",Id("a"),IntLiteral(1))))))))
    assert(checkAst(input,expected,237))
  }
   test("stmt 3.4: complex  dowhile stmt 1"){
    val input = """
    void main(){
      do
        if(2>3) a = 5;
        else {
          do  1+2+3; foo(2);
          while (a==10);
        }
      while a==1;
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(Dowhile(List(If(BinaryOp(">",IntLiteral(2),IntLiteral(3)),BinaryOp("=",Id("a"),IntLiteral(5)),
        Some(Block(List(),List(Dowhile(List(BinaryOp("+",BinaryOp("+",IntLiteral(1),IntLiteral(2)),IntLiteral(3)),
          CallExpr(Id("foo"),List(IntLiteral(2)))),BinaryOp("==",Id("a"),IntLiteral(10)))))))),
      BinaryOp("==",Id("a"),IntLiteral(1))))))))
    assert(checkAst(input,expected,238))
  }
  test("stmt 3.4: complex  dowhile stmt 2"){
    val input = """
    void main(){
      if(a==2)
      do {
        int a;
        a  = 3;
        if(a<2) 1;
        else foo(a+4);
      }
      while a==1;
      else {float b[7];}
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(If(BinaryOp("==",Id("a"),IntLiteral(2)),Dowhile(List(Block(List(VarDecl(Id("a"),
        IntType)),List(BinaryOp("=",Id("a"),IntLiteral(3)),If(BinaryOp("<",Id("a"),IntLiteral(2)),
        IntLiteral(1),Some(CallExpr(Id("foo"),List(BinaryOp("+",Id("a"),IntLiteral(4))))))))),BinaryOp("==",Id("a"),IntLiteral(1))),
      Some(Block(List(VarDecl(Id("b"),ArrayType(IntLiteral(7),FloatType))),List()))))))))
    assert(checkAst(input,expected,239))
  }
   test("stmt 3.4: complex  dowhile stmt 3"){
    val input = """
    void main(){
      if(foo(2)>3)
        if(2==2) {
          int i;
          float sum; 
          i = 0;
          sum =0;
          do i = i + 1; sum = sum + i; while (i<10);
        }else{
          if(true != false) 1+2+3;
          else {
            function_programing(4,5,6)[3] = 5/7;
          }
        }
    }
    """
    val expected =Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),List(If(BinaryOp(">",CallExpr(Id("foo"),
      List(IntLiteral(2))),IntLiteral(3)),If(BinaryOp("==",IntLiteral(2),IntLiteral(2)),Block(List(VarDecl(Id("i"),IntType),
        VarDecl(Id("sum"),FloatType)),List(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("=",Id("sum"),IntLiteral(0)),
        Dowhile(List(BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),BinaryOp("=",Id("sum"),BinaryOp("+",Id("sum"),Id("i")))),
          BinaryOp("<",Id("i"),IntLiteral(10))))),Some(Block(List(),List(If(BinaryOp("!=",BooleanLiteral(true),BooleanLiteral(false)),
            BinaryOp("+",BinaryOp("+",IntLiteral(1),IntLiteral(2)),IntLiteral(3)),Some(Block(List(),
              List(BinaryOp("=",ArrayCell(CallExpr(Id("function_programing"),List(IntLiteral(4),IntLiteral(5),IntLiteral(6))),
                IntLiteral(3)),BinaryOp("/",IntLiteral(5),IntLiteral(7))))))))))),None))))))
    assert(checkAst(input,expected,240))
  }
  test("stmt 4.1: simple forstmt 1"){
    val input = """
    void main(){
      for (1;2;3) {}
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(For(IntLiteral(1),IntLiteral(2),IntLiteral(3),Block(List(),List())))))))
    assert(checkAst(input,expected,241))
  }
  test("stmt 4.1: simple forstmt 2"){
    val input = """
    void main() {
    for (1;2;3) 1;
  }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(For(IntLiteral(1),IntLiteral(2),IntLiteral(3),IntLiteral(1)))))))
    assert(checkAst(input,expected,242))
  }
  test("stmt 4.1: simple forstmt 3"){
    val input = """
    void main() {
    for (i = 0; i<10; i= i+1 ) writeln;
  }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(10)),BinaryOp("=",Id("i"),
        BinaryOp("+",Id("i"),IntLiteral(1))),Id("writeln")))))))
    assert(checkAst(input,expected,243))
  }
   test("stmt 4.1: simple forstmt 4"){
    val input = """
    void main() {
    for (i = 0; i<10; i= i+1 ) writeln();
  }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),List(For(BinaryOp("=",Id("i"),IntLiteral(0)),
      BinaryOp("<",Id("i"),IntLiteral(10)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),
      CallExpr(Id("writeln"),List())))))))
    assert(checkAst(input,expected,244))
  }
  test("stmt 4.2:  nest forstmt 1"){
    val input = """
    void main() {
    for (i = 0; i<10; false ) 
      for (true;flase; 3) i = i+1;
    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(10)),
        BooleanLiteral(false),For(BooleanLiteral(true),Id("flase"),IntLiteral(3),
          BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))))))))))
    assert(checkAst(input,expected,245))
  }
  test("stmt 4.2:  nest forstmt 2"){
    val input = """
    void main() {
      int i;
    for (i = 0; i>-10; i = i-1) {
      int j;
      for (j = 10; j<100; j = j+1) i = j+1;
    }
              }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(VarDecl(Id("i"),IntType)),
      List(For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp(">",Id("i"),UnaryOp("-",IntLiteral(10))),
        BinaryOp("=",Id("i"),BinaryOp("-",Id("i"),IntLiteral(1))),
        Block(List(VarDecl(Id("j"),IntType)),List(For(BinaryOp("=",Id("j"),IntLiteral(10)),
          BinaryOp("<",Id("j"),IntLiteral(100)),BinaryOp("=",Id("j"),BinaryOp("+",Id("j"),
            IntLiteral(1))),BinaryOp("=",Id("i"),BinaryOp("+",Id("j"),IntLiteral(1))))))))))))
    assert(checkAst(input,expected,246))
  }
    test("stmt 4.3:  complex forstmt 1"){
    val input = """
    void main() {
    for (i = 0; i < 10; i = i-1)
      if(3==3)i = i+1; else i= i-1;
              }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),
        IntLiteral(10)),BinaryOp("=",Id("i"),BinaryOp("-",Id("i"),IntLiteral(1))),
      If(BinaryOp("==",IntLiteral(3),IntLiteral(3)),BinaryOp("=",Id("i"),
        BinaryOp("+",Id("i"),IntLiteral(1))),Some(BinaryOp("=",Id("i"),BinaryOp("-",Id("i"),IntLiteral(1)))))))))))
    assert(checkAst(input,expected,247))
  }
    test("stmt 4.3:  complex forstmt 2"){
    val input = """
    void main() {
    for (i = 0; i < 10; i = i-1)
      do i = i  + 10; while(i <100);
              }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),List(For(BinaryOp("=",Id("i"),
      IntLiteral(0)),BinaryOp("<",Id("i"),IntLiteral(10)),BinaryOp("=",Id("i"),BinaryOp("-",Id("i"),
        IntLiteral(1))),Dowhile(List(BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),
          IntLiteral(10)))),BinaryOp("<",Id("i"),IntLiteral(100)))))))))
    assert(checkAst(input,expected,248))
  }
    test("stmt 4.3:  complex forstmt 3"){
    val input = """
    void main() {
    for (i = 0; i < 100; i = i-1)
      if(3==3) i = i+1; else 
        do {} while(true);
              }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(),
      List(For(BinaryOp("=",Id("i"),IntLiteral(0)),BinaryOp("<",Id("i"),
        IntLiteral(100)),BinaryOp("=",Id("i"),BinaryOp("-",Id("i"),IntLiteral(1))),
      If(BinaryOp("==",IntLiteral(3),IntLiteral(3)),BinaryOp("=",Id("i"),
        BinaryOp("+",Id("i"),IntLiteral(1))),Some(Dowhile(List(Block(List(),List())),BooleanLiteral(true))))))))))
    assert(checkAst(input,expected,249))
  }
    test("stmt 4.3:  complex forstmt 4"){
    val input = """
    void main() {
    int i;
    float a[1000];
    for (i = 0; i < 100; i = i+1)
      if(i%2==0) a[i] = i;
      else 
        for(i = 2; i>-100; i = i-1)
          do writeln(i); i = i + 1; while(i<100);
                    }
    """
    val expected = Program(List(FuncDecl(Id("main"),List(),VoidType,Block(List(VarDecl(Id("i"),IntType),VarDecl(Id("a"),
      ArrayType(IntLiteral(1000),FloatType))),List(For(BinaryOp("=",Id("i"),IntLiteral(0)),
      BinaryOp("<",Id("i"),IntLiteral(100)),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),IntLiteral(1))),
      If(BinaryOp("==",BinaryOp("%",Id("i"),IntLiteral(2)),IntLiteral(0)),
        BinaryOp("=",ArrayCell(Id("a"),Id("i")),Id("i")),
        Some(For(BinaryOp("=",Id("i"),IntLiteral(2)),BinaryOp(">",Id("i"),UnaryOp("-",IntLiteral(100))),
          BinaryOp("=",Id("i"),BinaryOp("-",Id("i"),IntLiteral(1))),
          Dowhile(List(CallExpr(Id("writeln"),List(Id("i"))),BinaryOp("=",Id("i"),BinaryOp("+",Id("i"),
            IntLiteral(1)))),BinaryOp("<",Id("i"),IntLiteral(100))))))))))))
    assert(checkAst(input,expected,250))
  }


}
